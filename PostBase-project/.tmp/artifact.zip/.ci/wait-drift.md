## Settled-wait record — ✅ no crossing line the settlements do not produce

- **Settled-wait drift** — 0 crossing lines: every line the record holds is one these settlements produce.
- **Collect-wait drift** — 0 crossing lines: every line the record holds is one these settlements produce.

The settle step is `continue-on-error` so that a record it could not write cannot stop the run page, the comment and the artifact; this is the verdict taken on the record it left, and nothing about it failed — the night is not stopped for this.

This is written down rather than left to the absence of a file: a night in which the check held and a night in which it never ran are two different things to a reader of an artifact, and a missing file says neither.
