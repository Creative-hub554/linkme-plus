## Nightly full CI gate — ❌ 2 of 10 stage(s) failed

The whole gate, run end to end on a clean checkout — no `--changed-only`, so nothing is skipped.

- Ran 10 stage(s): 8 passed, 2 failed.
- Failed: `test`, `mutation`.
- Excluded by `--skip` (this host cannot run it): `preflight`.

| Stage | Result | Summary |
| :-- | :-- | :-- |
| typecheck | ✅ pass | 0 type error(s) |
| runbook contents | ✅ pass | 62 section(s), Contents up to date |
| lint baseline | ✅ pass | 563 file(s), no findings |
| vitest suite | ❌ fail | 2 of 3331 test(s) failed |
| gate drift | ✅ pass | 58 gate file(s) pinned, all match |
| vocabulary smoke | ✅ pass | 1 demonstration stamp(s) checked, no survivors |
| fifth vocabulary smoke | ✅ pass | 1 demonstration stamp(s) checked, no survivors |
| coverage gate mutation | ✅ pass | 5 coverage gate(s) checked, no survivors |
| preflight mutation sweep | ✅ pass | 28 preflight mutation(s) checked, no survivors |
| mutation sweep | ❌ fail | 766 checked, 24 survivor(s): 9 guard, 9 fail-open guard, 6 undriven catch — 0 thin-margin limb(s) — 62 of 80 decision(s) un-struck |

### The verification queue's alarm

The armed suite judged the pending queue at 2026-10-20T00:58:56.639Z — no application had exceeded its 48-hour review window; nobody owes a review.

### Coverage

rendered-links coverage: chrome — the footer 13, the signed-in header 5, the opened account menu 5, the opened mobile panel 3, the opened notification panel 2, the bottom nav 3, the Social strip 1, the signed-out header 5, the signed-out mobile panel 4, the signed-out bottom nav 2 (25 unique destinations) | data — 28 page mounts, 18 unique destinations.

scratch-paths coverage: 10 suite(s) keep a scratch directory and were judged — src/test/ci-runner-tree-editing.test.ts, src/test/ci-runner.test.ts, src/test/ci-stage-order.test.ts, src/test/convention-guards.test.ts, src/test/coverage-backfill.test.ts, src/test/coverage-low-water.test.ts, src/test/coverage-trend.test.ts, src/test/leak-watch-jsdom.test.ts, src/test/leak-watch.test.ts, src/test/scratch.test.ts (243 test file(s) scanned).

convention-guards coverage: 13 guard(s) exercised on both of their shapes — beat-clock, beat-seam, body-clear, client-config, client-env, frozen-scratch, mount, public-vocabulary, relative-fixture, runbook, settle, stale-stage-lists, stylesheet.

queue-settled coverage: 0 pending application(s) — judged 2026-10-20T00:58:56.639Z against a 48h window; 0 owed past it..

### Coverage over time

From the committed runbook's dated records (`.freebuff/run.md`) and the nightly history table (`.freebuff/coverage-history.md`), oldest first and one record per night — each reading's own line, plotted by the number it declares. A record that carried no reading for a guard is left out of that guard's chart rather than counted as a zero, a line the metric cannot read is named instead of plotted, and a night only the table recorded is charted like any other.

Beneath each series is the floor that reading is held against — the level its records have settled to, recorded with the night it settled in `.freebuff/coverage-low-water.json` — drawn on the series' own scale, so the bars can be read against the level a fall is measured from and not only against each other.

- **rendered-links** `█▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁` — 25 chrome unique destinations, down 3 from 28 (range 25–28) over the last 20 of 37 record(s) (2026-10-08 → 2026-10-20)
  `▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁▁` floor 25 (recorded 2026-10-09) — the newest 25 is level with it
- **scratch-paths** `▁▁▃▃██` — 10 judged suites, up 3 from 7 (range 7–10) over 6 record(s) (2026-10-13 → 2026-10-20)
  `▁▁▁▁▁▁` floor 7 (recorded 2026-10-13) — the newest 10 is 3 above it
- **convention-guards** `▄▄▄▄▄▄` — 13 guards exercised, no change from 13 (range 13–13) over 6 record(s) (2026-10-13 → 2026-10-20)
  `▄▄▄▄▄▄` floor 13 (recorded 2026-10-13) — the newest 13 is level with it
- **queue-settled** `▄` — 0 pending applications, no change from 0 (range 0–0) over 1 record(s) (2026-10-19)
  charted without a floor, deliberately — this reading's number is how much work remains, and a drain past the lowest night is good news a red would lie about

### Failures

**vitest suite** — 2 of 3331 test(s) failed
- **FAIL** `src/test/house-timeout.test.ts` — ENOENT: no such file or directory, open '../../.ci/gate-content/vitest.config.ts'
- **FAIL** `src/test/coverage-history.test.ts` — holds rows that are as wide as the table, reading by reading
- **FAIL** `src/test/preview-preflight.test.ts` — keeps the stale-lock advice for a dead pid, so the two cases are told apart

**mutation sweep** — 766 checked, 24 survivor(s): 9 guard, 9 fail-open guard, 6 undriven catch — 0 thin-margin limb(s) — 62 of 80 decision(s) un-struck
- **SURVIVED GUARD** `src/app/api/admin/roles/route.ts:116` — if (!userId || !isUuid(userId))
- **SURVIVED GUARD** `src/app/api/admin/roles/route.ts:166` — if (!updated)
- **SURVIVED FAIL-OPEN** `src/app/api/admin/roles/route.ts:116` — if (!userId || !isUuid(userId)) [fail-open]
- **SURVIVED FAIL-OPEN** `src/app/api/admin/roles/route.ts:166` — if (!updated) [fail-open]
- **UNDRIVEN CATCH** `src/app/api/admin/roles/route.ts:169` — catch {...}
- **SURVIVED GUARD** `src/app/api/admin/verification-requests/route.ts:62` — if (!reviewer || reviewer.role !== "admin")
- **SURVIVED GUARD** `src/app/api/admin/verification-requests/route.ts:68` — if (!application)
- **SURVIVED GUARD** `src/app/api/admin/verification-requests/route.ts:92` — if (!updated)
- **SURVIVED GUARD** `src/app/api/admin/verification-requests/route.ts:95` — if (err && typeof err === "object" && "code" in err && err.code === "23505")
- **SURVIVED FAIL-OPEN** `src/app/api/admin/verification-requests/route.ts:62` — if (!reviewer || reviewer.role !== "admin") [fail-open]
- **SURVIVED FAIL-OPEN** `src/app/api/admin/verification-requests/route.ts:68` — if (!application) [fail-open]
- **SURVIVED FAIL-OPEN** `src/app/api/admin/verification-requests/route.ts:92` — if (!updated) [fail-open]
- **SURVIVED FAIL-OPEN** `src/app/api/admin/verification-requests/route.ts:95` — if (err && typeof err === "object" && "code" in err && err.code === "23505") [fail-open]
- **UNDRIVEN CATCH** `src/app/api/admin/verification-requests/route.ts:37` — catch {...}
- **UNDRIVEN CATCH** `src/app/api/admin/verification-requests/route.ts:50` — catch {...}
- **SURVIVED GUARD** `src/app/api/users/block/route.ts:20` — if (!userId)
- **SURVIVED GUARD** `src/app/api/users/block/route.ts:21` — if (!isUuid(userId))
- **SURVIVED GUARD** `src/app/api/users/block/route.ts:22` — if (userId === session.user.id)
- **SURVIVED FAIL-OPEN** `src/app/api/users/block/route.ts:20` — if (!userId) [fail-open]
- **SURVIVED FAIL-OPEN** `src/app/api/users/block/route.ts:21` — if (!isUuid(userId)) [fail-open]
- **SURVIVED FAIL-OPEN** `src/app/api/users/block/route.ts:22` — if (userId === session.user.id) [fail-open]
- **UNDRIVEN CATCH** `src/app/api/users/block/route.ts:35` — catch {...}
- **UNDRIVEN CATCH** `src/app/api/verification-requests/route.ts:42` — catch {...}
- **UNDRIVEN CATCH** `src/app/api/verification-requests/route.ts:56` — catch {...}

> A stage listed as excluded was **not run** in this job; a pass here does not cover it.

## Settled-wait record — ✅ no crossing line the settlements do not produce

- **Settled-wait drift** — 0 crossing lines: every line the record holds is one these settlements produce.
- **Collect-wait drift** — 0 crossing lines: every line the record holds is one these settlements produce.

The settle step is `continue-on-error` so that a record it could not write cannot stop the run page, the comment and the artifact; this is the verdict taken on the record it left, and nothing about it failed — the night is not stopped for this.

This is written down rather than left to the absence of a file: a night in which the check held and a night in which it never ran are two different things to a reader of an artifact, and a missing file says neither.
