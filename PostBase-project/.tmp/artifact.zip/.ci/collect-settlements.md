### Collect-budget proposals answered

Every collect-budget proposal this job has left on a pull request that somebody has since
answered, read from the runbook's own records (`.freebuff/run.md`): the nightly job appends one
line per settlement, so the nights below are the age a proposal actually sat, not a reading of it.
And it is the age of the *comment* — the day the job first proposed the tightening — rather than
of the pull request it was posted on, so a proposal made a week into a branch is not recorded as a
week of being ignored.

A record's own word is what the reply did, not merely that there was one: the apply job declares its outcome in the reply it posts (`applied`, `unchanged`, `no-payload`, `refused`, `drift`, `unverified`, `fork`, `unknown`), and the runbook states that word, so a tightening that was adopted and one that was refused are two different records rather than one answer with a date on it. A reply that declares no outcome at all — one the job posted before this vocabulary existed — still reads as the plain `answered` it always did.

`STALE_NIGHTS` (3) and `ESCALATED_NIGHTS` (7) are the clock
this job keeps for its own floor proposal: where the run page starts naming a request, and where a
comment starts naming a person. A collect proposal has no escalation of its own — nothing re-fires
it and nothing mentions anybody for it — so the tables below read these ages against that one clock
rather than against a loudness this kind has not got.

#### Where the ages landed

Every settlement recorded so far, counted by the band its age falls in — the same three
boundaries the records' own lines name, so the table and the wording of the records cannot
disagree:

| band | answered | share |
| :-- | --: | --: |
| before either threshold | 6 | 100% |
| after the run page | 0 | 0% |
| after the escalation | 0 | 0% |

Shares are whole percents, so the column may read 99 or 101 where it should read 100. The
fastest answer came after 0 nights and the slowest after 0, which is the spread these bands are a coarse reading of.

#### How often the escalation mattered

| the answer came | answers | nights past the clock's loud end |
| :-- | --: | --: |
| the day that clock's loud end is reached (`ESCALATED_NIGHTS` = 7) | 0 | 0 |
| later than that | 0 | 0 |
| before that clock's loud end was reached | 6 | — |

Nothing here has reached the clock's loud end yet: every one of the 6 answers arrived inside the 7 nights at which the job's own floor request starts naming a person. A collect proposal is escalated by no comment of this job's and mentions nobody, so the table below is that clock read on a request the job does not shout about — and the first row to leave zero is the first evidence of what these ages look like past it.

#### How the median wait moved

One point per night an answer arrived, oldest first: the median of every age recorded up to and
including that night, and a night nothing was answered adds no point because there is no new age
for a median to move on. The tables above are read one age at a time — an answer either crossed a
threshold or it did not — while this line is read across them, so the middle of the ages can climb
toward a threshold over several answers before any single one of them crosses it, which is the
drift the bands have nothing to say about. The count behind each point is printed for the reason
the median is: a median over three answers moves whenever one of them sat longer than half of the
rest, so a rise here is the earliest a drift can be *seen* rather than evidence that one is
happening.

| night answered | ages that arrived | ages so far | median so far | change |
| :-- | :-- | --: | --: | --: |
| 2026-10-05 | 0, 0, 0, 0, 0 | 5 | 0 | — |
| 2026-10-06 | 0 | 6 | 0 | 0 |

- **median wait** `▁▁` — 0 nights, no change from 0 (range 0–0) over 2 nights an answer arrived on (2026-10-05 → 2026-10-06), on a scale of 0 → 7 nights, the span the two thresholds divide (`STALE_NIGHTS` = 3, `ESCALATED_NIGHTS` = 7).

The median has not moved from 0 nights across the 2 nights an answer arrived on. The newest median, 0 nights, is inside the first threshold: 3 nights short of the night the job's own floor request starts being named on the run page (`STALE_NIGHTS` = 3).

Every one of them, oldest answer first:

| proposal | answered | nights | how it was answered | pull request |
| :-- | :-- | --: | :-- | :-- |
| #2 | 2026-10-05 | 0 | closed without the reply, before either threshold | closed 2026-10-05 |
| #3 | 2026-10-05 | 0 | closed without the reply, before either threshold | closed 2026-10-05 |
| #5 | 2026-10-05 | 0 | closed without the reply, before either threshold | closed 2026-10-05 |
| #6 | 2026-10-05 | 0 | closed without the reply, before either threshold | closed 2026-10-05 |
| #7 | 2026-10-05 | 0 | closed without the reply, before either threshold | closed 2026-10-05 |
| #9 | 2026-10-06 | 0 | closed without the reply, before either threshold | closed 2026-10-06 |

**6 of these requests are recorded as gone.** The last column is the state of the pull request each ask was left on rather than of the ask itself, read from the runbook's own record of the close: one that went away with its ask unanswered is closed on the day its settlement line states, and one whose ask was answered before it went is closed on the day its own close line states. A comment this job left on either is written to a thread nobody is watching, which is why the gate that keeps those comments current leaves an ended request alone. A request the record has since recorded as *reopened* is not one of these: the cell is not rendered for it, because the last thing the file says about that pull request is that it came back.

A dash there is a request the runbook does not record as closed, which is not the same as one still standing: the settle step records a close only while that pull request is inside the window it reads, so a request closed outside it waits for a later night to be seen, and one whose ask was answered and which is still open has no line at all.

A column of ages inside the first threshold is a proposal that answered itself; one past the
second is a question that sat through the point at which the job's own request would have been
naming a person, with nothing in the job saying so. Both are read against the same two numbers,
which is the whole of what these lines are for.

